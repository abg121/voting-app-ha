--
-- PostgreSQL database cluster dump
--

\restrict K3rUOhMdc8hSwg0hceQ4P7NukaoObcAmwcWhXOIHjDbL6QrN2ikfe9d6uF8R6MM

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:K1rX0Phd7ED+fbuP92d+Ng==$L5UidSSyWz/tAn3E+p8py9LqLG57+47zBhAoSLxCUgQ=:djK8Ja2l8V+hxNwht08AWtpgeIZu3esqQ6XbWoOjnCk=';
CREATE ROLE replicator;
ALTER ROLE replicator WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN REPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:5UuFswtMucbSTFQqdhWBhQ==$NFRVoE3enibYh9lzjuhm3OkQnwMmXjGRc5NbzmS6BPw=:+udVh/sMS6ofFyHevqxaDiHw+GSnZaPCF5Vjx7Z7N+U=';

--
-- User Configurations
--








\unrestrict K3rUOhMdc8hSwg0hceQ4P7NukaoObcAmwcWhXOIHjDbL6QrN2ikfe9d6uF8R6MM

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict R0H3dfeIU6bSe0FybOQa71zyfqVDj853LDJPQDzNoxkcUhkDPqes7gAde2HUajf

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict R0H3dfeIU6bSe0FybOQa71zyfqVDj853LDJPQDzNoxkcUhkDPqes7gAde2HUajf

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict KxEIqZ9ogOx7mt4s3uO9gGkLRBb3Bz05nIkoyNE2W5JMR4EtN9rl7fRRD8N4K28

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: test_lb(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.test_lb() RETURNS text
    LANGUAGE sql
    AS $$ SELECT 'Load balance test' $$;


ALTER FUNCTION public.test_lb() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: baseline_test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.baseline_test (
    id integer NOT NULL,
    test_time timestamp without time zone
);


ALTER TABLE public.baseline_test OWNER TO postgres;

--
-- Name: baseline_test_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.baseline_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.baseline_test_id_seq OWNER TO postgres;

--
-- Name: baseline_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.baseline_test_id_seq OWNED BY public.baseline_test.id;


--
-- Name: final_test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.final_test (
    id integer NOT NULL,
    data text
);


ALTER TABLE public.final_test OWNER TO postgres;

--
-- Name: final_test_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.final_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.final_test_id_seq OWNER TO postgres;

--
-- Name: final_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.final_test_id_seq OWNED BY public.final_test.id;


--
-- Name: ha_test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ha_test (
    id integer NOT NULL,
    test_data text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ha_test OWNER TO postgres;

--
-- Name: ha_test_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ha_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ha_test_id_seq OWNER TO postgres;

--
-- Name: ha_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ha_test_id_seq OWNED BY public.ha_test.id;


--
-- Name: stable_test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stable_test (
    id integer NOT NULL,
    data text
);


ALTER TABLE public.stable_test OWNER TO postgres;

--
-- Name: stable_test_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stable_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stable_test_id_seq OWNER TO postgres;

--
-- Name: stable_test_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stable_test_id_seq OWNED BY public.stable_test.id;


--
-- Name: test_ha; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_ha (
    id integer NOT NULL,
    data text
);


ALTER TABLE public.test_ha OWNER TO postgres;

--
-- Name: test_ha_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_ha_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.test_ha_id_seq OWNER TO postgres;

--
-- Name: test_ha_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_ha_id_seq OWNED BY public.test_ha.id;


--
-- Name: test_worker; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_worker (
    id integer NOT NULL,
    name text
);


ALTER TABLE public.test_worker OWNER TO postgres;

--
-- Name: test_worker_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_worker_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.test_worker_id_seq OWNER TO postgres;

--
-- Name: test_worker_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_worker_id_seq OWNED BY public.test_worker.id;


--
-- Name: votes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.votes (
    id character varying(50) NOT NULL,
    vote character varying(10) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.votes OWNER TO postgres;

--
-- Name: baseline_test id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.baseline_test ALTER COLUMN id SET DEFAULT nextval('public.baseline_test_id_seq'::regclass);


--
-- Name: final_test id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.final_test ALTER COLUMN id SET DEFAULT nextval('public.final_test_id_seq'::regclass);


--
-- Name: ha_test id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ha_test ALTER COLUMN id SET DEFAULT nextval('public.ha_test_id_seq'::regclass);


--
-- Name: stable_test id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stable_test ALTER COLUMN id SET DEFAULT nextval('public.stable_test_id_seq'::regclass);


--
-- Name: test_ha id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_ha ALTER COLUMN id SET DEFAULT nextval('public.test_ha_id_seq'::regclass);


--
-- Name: test_worker id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_worker ALTER COLUMN id SET DEFAULT nextval('public.test_worker_id_seq'::regclass);


--
-- Data for Name: baseline_test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.baseline_test (id, test_time) FROM stdin;
1	2025-11-28 23:02:52.236736
\.


--
-- Data for Name: final_test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.final_test (id, data) FROM stdin;
1	success_via_pgpool
\.


--
-- Data for Name: ha_test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ha_test (id, test_data, created_at) FROM stdin;
1	write_test_through_pgpool	2025-11-28 21:46:08.24397
\.


--
-- Data for Name: stable_test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stable_test (id, data) FROM stdin;
1	stable_configuration
2	before_outage
\.


--
-- Data for Name: test_ha; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_ha (id, data) FROM stdin;
1	test from haproxy
\.


--
-- Data for Name: test_worker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_worker (id, name) FROM stdin;
\.


--
-- Data for Name: votes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.votes (id, vote, created_at) FROM stdin;
aeccb74d390b357	a	2025-11-25 18:44:48.460209
dffab26b397d895	b	2025-11-25 20:03:13.551253
a84b0501307969	a	2025-11-26 08:51:33.046291
8104c0d73a78fbd	a	2025-11-26 19:34:20.785148
5bdaace7d5655d1	b	2025-11-26 19:34:20.905712
185b506261bd9a2	a	2025-11-26 08:48:46.628458
f1b2a5f96467b5f	b	2025-11-25 20:12:30.815694
\.


--
-- Name: baseline_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.baseline_test_id_seq', 1, true);


--
-- Name: final_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.final_test_id_seq', 1, true);


--
-- Name: ha_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ha_test_id_seq', 1, true);


--
-- Name: stable_test_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stable_test_id_seq', 2, true);


--
-- Name: test_ha_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_ha_id_seq', 1, true);


--
-- Name: test_worker_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_worker_id_seq', 1, false);


--
-- Name: baseline_test baseline_test_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.baseline_test
    ADD CONSTRAINT baseline_test_pkey PRIMARY KEY (id);


--
-- Name: final_test final_test_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.final_test
    ADD CONSTRAINT final_test_pkey PRIMARY KEY (id);


--
-- Name: ha_test ha_test_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ha_test
    ADD CONSTRAINT ha_test_pkey PRIMARY KEY (id);


--
-- Name: stable_test stable_test_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stable_test
    ADD CONSTRAINT stable_test_pkey PRIMARY KEY (id);


--
-- Name: test_worker test_worker_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_worker
    ADD CONSTRAINT test_worker_pkey PRIMARY KEY (id);


--
-- Name: votes votes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.votes
    ADD CONSTRAINT votes_pkey PRIMARY KEY (id);


--
-- Name: pub; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION pub FOR ALL TABLES WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION pub OWNER TO postgres;

--
-- PostgreSQL database dump complete
--

\unrestrict KxEIqZ9ogOx7mt4s3uO9gGkLRBb3Bz05nIkoyNE2W5JMR4EtN9rl7fRRD8N4K28

--
-- PostgreSQL database cluster dump complete
--

